#include <cstdlib>
#include <iostream>

using namespace std;

typedef struct {
    // TODO: complete struct
} Student;

int compare(const void* p1, const void* p2) {
    // TODO: complete compare function for qsort()
}

int main() {
    // TODO: read input

    // TODO: sort array with qsort()

    // TODO: print result

    return 0;
}