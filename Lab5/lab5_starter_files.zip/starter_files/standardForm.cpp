#include <cmath>
#include "standardForm.h"

QuadraticFunction::QuadraticFunction(float a_in, float b_in, float c_in){}
// TODO: implement this constructor

float QuadraticFunction::getA() const {
    return a;
}

float QuadraticFunction::getB() const {
    return b;
}

float QuadraticFunction::getC() const {
    return c;
}

float QuadraticFunction::evaluate(float x) {
    // TODO: implement this function
}

Root QuadraticFunction::getRoot() {
    // TODO: implement this function
}

bool QuadraticFunction::intersect(QuadraticFunction q){
    // TODO: implement this function
}