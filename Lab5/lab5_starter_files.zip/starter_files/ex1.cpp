#include "ex1.h"

int dot(list_t v1, list_t v2){
	// TODO: implement dot function
}

list_t filter(list_t list, bool (*fn)(int)){
	// TODO: implement filter function
}

bool is_palindrome_list(list_t list){
	// TODO: implement is_palindrome_list function
}
